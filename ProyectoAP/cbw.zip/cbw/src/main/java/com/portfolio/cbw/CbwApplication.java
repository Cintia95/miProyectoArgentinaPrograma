package com.portfolio.cbw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbwApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbwApplication.class, args);
	}

}
